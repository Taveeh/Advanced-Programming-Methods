package Exceptions;

public class ConditionException extends InterpreterException {
    public ConditionException(String message) {
        super(message);
    }
}

package Exceptions;

public class DeclarationException extends InterpreterException {
    public DeclarationException(String message) {
        super(message);
    }
}

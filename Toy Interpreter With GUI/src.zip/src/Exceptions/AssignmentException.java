package Exceptions;

public class AssignmentException extends InterpreterException {
    public AssignmentException(String message) {
        super(message);
    }
}

package Exceptions;

public class ADTException extends InterpreterException {
    public ADTException(String msg) {
        super(msg);
    }
}

package Exceptions;

public class ExecutionException extends InterpreterException {

    public ExecutionException(String message) {
        super(message);
    }
}
